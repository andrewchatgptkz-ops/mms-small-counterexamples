#!/usr/bin/env python3
"""Standalone standard-library checker: no optimisation library is required.
Checks the T=104 example and the exact parametric max-min theorem.
Run from any directory: python /path/to/verify_new_certificate.py
"""
from pathlib import Path
from array import array
import json
P=Path(__file__).resolve().parent
base=json.loads((P/'8x19_score2.json').read_text())
d=json.loads((P/'8x19_depth2.json').read_text())
m=19;N=1<<m;T=104
assert d['agents']==8 and d['a']==d['b']==4 and d['goods']==m and d['T']==T
assert d['branch_goods']==[1,2]
def subsets(values):
 s=array('i',[0])
 for x in values:
  s.extend(array('i',(v+x for v in s)))
 return s
for t,key in [('R','rows_R_sum_T'),('C','cols_C_sum_T')]:
 assert len(d[t])==m and all(isinstance(x,int) and 0<x<T for x in d[t])
 assert sorted(g for block in d[key] for g in block)==list(range(1,m+1))
 assert all(sum(d[t][g-1] for g in block)==T for block in d[key])
 assert all(sum(base[t][g-1] for g in block)==26 for block in d[key])
 assert all(sum(d['direction_'+t][g-1] for g in block)==0 for block in d[key])
 assert d[t]==[4*v+h for v,h in zip(base[t],d['direction_'+t])]
 assert all(0<3*v+h<78 for v,h in zip(base[t],d['direction_'+t]))
print('Both exact witness partitions verified; MMS = 104 for all eight agents.')
sv={t:subsets(d[t]) for t in ['R','C']};bv={t:subsets(base[t]) for t in ['R','C']};hv={t:subsets(d['direction_'+t]) for t in ['R','C']}
for leaf,c in d['certificates'].items():
 assert len(c['w'])==m and all(isinstance(x,int) and x>=0 for x in c['w'])
 margin=4*c['alpha']+4*c['beta']-sum(c['w']);assert margin>=1
 ws=subsets(c['w']);mins=[]
 for t,q in [('R',c['alpha']),('C',c['beta'])]:
  forbidden=sum(1<<j for j,l in enumerate(leaf) if l!=t)
  mn=10**9;max0=max4=max3=-10**9
  for S in range(N):
   if S&forbidden:continue
   if sv[t][S]>=T:mn=min(mn,ws[S])
   if ws[S]<q:
    max0=max(max0,bv[t][S]);max4=max(max4,4*bv[t][S]+hv[t][S]);max3=max(max3,3*bv[t][S]+hv[t][S])
  assert mn>=q
  # These endpoints imply the upper envelope on [0,1/4] and [1/4,1/3].
  assert max0<=26 and max4<=103 and max3<=78
  mins.append(mn)
  print(f'{leaf}/{t}: min winning weight={mn}, poor-set endpoint maxima={max0}, {max4}/4, {max3}/3')
 print(f'{leaf}: total={sum(c["w"])}, quota={4*c["alpha"]+4*c["beta"]}, margin={margin}')
A={'R':[[4,5,6],[9,10,11],[14,15],[18,19]],'C':[[3,8],[12,13],[7,16],[1,2,17]]}
B={'R':[[2,6],[5,10,12],[11,14],[15,18]],'C':[[1,4,9],[8,13],[7,16],[3,17,19]]}
for name,alloc,intercept,slope in [('A',A,26,-1),('B',B,25,3)]:
 assert sorted(g for t in ['R','C'] for block in alloc[t] for g in block)==list(range(1,m+1))
 coeff=[]
 for t in ['R','C']:
  assert len(alloc[t])==4
  for S in alloc[t]:
   u=sum(base[t][g-1] for g in S);v=sum(d['direction_'+t][g-1] for g in S)
   assert u>=intercept and 3*u+v>=3*intercept+slope;coeff.append((u,v))
 assert (intercept,slope) in coeff
 print(name,'utility intercept/slope pairs:',coeff)
utilities=[sum(d[t][g-1] for g in S) for t in ['R','C'] for S in A[t]]
assert min(utilities)==103
print('Exact T104 max-min = 103, witnessed by utilities',utilities)
print('Exact parametric max-min = max(26-epsilon,25+3*epsilon), 0 <= epsilon <= 1/3.')
print('Hard rows:',[j+1 for j,row in enumerate(d['rows_R_sum_T']) if sum(d['C'][g-1] for g in row)>=T])
print('Hard columns:',[j+1 for j,col in enumerate(d['cols_C_sum_T']) if sum(d['R'][g-1] for g in col)>=T])
print('NEW CERTIFICATE AND PARAMETRIC THEOREM VALID')
