# MMS theory session: gadget signatures, depth-two certificates, and a new 8-agent example

## Status

1. **Gadget signature:** exact observed signatures and a fixed-quota cycle obstruction are proved. An autonomous periodic induction is **not proved**.
2. **Depth-two certificates:** **proved**. An explicit positive-integer 8-agent, 19-good example has MMS 104 and exact best minimum 103. More strongly, rational counterexamples occur arbitrarily close to the supplied score-two profile.
3. **Invariant:** the knapsack-polyhedron explanation and its exact lifting recurrence are **proved**. The all-n balanced-prism extension below is **conjectured**.

The supplied dossier was read, including section 8, before mathematical computation. The supplied verifier printed both `ALL CERTIFICATES VALID` and `CHAIN CERTIFICATES VALID`. No previous large exclusion search was rerun. Computation here comprised subset checks, checks of the supplied incidence graphs, three guarded packing checks, small LPs, and one bounded nearby-instance MILP that solved at one branch-and-bound node. No literature-novelty claim is made.

## 1. The gadget and the obstruction to a periodic induction

### 1.1 The graph operation and an exact finite local description

Write the substituted path as

    r --x-- c' --y-- r' --z-- c.

The old edge is retained at its row endpoint as x. The new row is {y,z}; the new column is {x,y}; the old column replaces the old edge by z. This specifies an incidence operation, not a valuation-update rule: the accepted transitions also repair valuations elsewhere.

For a three-good gadget G={x,y,z}, record, for every U subset of G,

    (max(0,T-R(U)), max(0,T-C(U)), w(U), U intersection {x,z}).

Together with the two ports' incident row/column totals, hard flags, and the new row/column data, this describes the local residual demands. A formal partial packing of G is a partition of a subset of its goods into nonempty blocks, each labelled R or C. Each block contributes its residual demand and its certificate weight. There are 47 such formal patterns, 22 when every good of G is used. These counts are before agent-count and exterior-feasibility filtering.

For exact interaction with a fixed exterior, additionally retain the traces of the complete minimal winning-set families: for every minimal winning set M, store (M intersection G, M minus G). A bundle U union X is winning precisely when it contains one of these minimal sets. Thus these traces, with the exterior disjoint-packing relation, reconstruct survivor feasibility exactly. This is finite for each supplied instance, but is not a constant-size autonomous state space as n grows.

All 47 transfer patterns, every local subset signature, and every complete minimal-winning-set trace are enumerated in `gadget_signatures.json`.

### 1.2 The observed numerical gadgets

For 4->5 there is no specified labelled valuation operator. Enumerating side-preserving isomorphisms from an edge subdivision of the 4x11 graph to the 5x13 graph gives four identifications and two distinct target paths. Both are shown. All weights below are from the post-transition case-R chain, with quotas (22,23); this does not claim that the 4-agent certificate transports to them.

| Identification | (x,y,z) | R on the path | C on the path | w on the path | Local minimal R-winners | Local minimal C-winners |
|---|---|---|---|---|---|---|
| 4->5 A | (8,13,12) | (24,4,25) | (26,3,27) | (17,6,17) | xz, yz | xy, xz, yz |
| 4->5 B | (13,8,7) | (4,24,5) | (3,26,7) | (6,17,6) | yz | xy, yz |
| 5->6 | (6,14,15) | (18,11,17) | (16,12,15) | (12,11,11) | xy, xz, yz | xy, xz |
| 6->7 | (7,16,17) | (4,22,5) | (4,23,6) | (6,17,6) | yz | xy, yz |

Here a hard row has C-value at least T and a hard column has R-value at least T. The following are post-transition data, in the order (old row port, old column port, new row, new column).

| Identification | Hard flags | Certificate weights |
|---|---|---|
| 4->5 A | (1,0,1,0) | (23,23,23,23) |
| 4->5 B | (1,0,1,0) | (23,24,23,23) |
| 5->6 | (0,0,0,1) | (22,23,22,23) |
| 6->7 | (1,0,1,0) | (23,23,23,23) |

The counts of unrestricted minimal winning sets with gadget-intersection masks in the order (empty,x,y,xy,z,xz,yz,xyz) are:

| Identification | R trace counts | C trace counts |
|---|---|---|
| 4->5 A | (51,8,28,2,8,1,1,0) | (48,8,22,1,9,1,1,0) |
| 4->5 B | (39,18,8,2,20,11,1,0) | (38,15,8,1,19,8,1,0) |
| 5->6 | (63,24,34,1,21,1,1,0) | (67,21,24,1,24,1,9,0) |
| 6->7 | (99,38,14,4,46,28,1,0) | (112,42,13,1,53,25,1,0) |

All four accepted target instances have zero full survivor packings at T, by their checked certificates. That does not make their residual transfer relations identical.

### 1.3 Why a two-port graph state is not an allocation state

Allocation bundles need not be connected in the incidence graph. In 6x15, the winning set {11,14} has R-value 29 and C-value 28, and meets the gadget {6,14,15} only at its internal middle edge 14. It uses neither end edge. Hence a graph algorithm allowing interaction only through two endpoint ports omits legal bundles.

There is also a direct nonlocality counterexample. Starting from accepted 6x15, change only C2 by +2 and C11 by -2. These goods share column c3, so all C-column sums remain 28. The gadget {6,14,15}, its old incident row r2 and column c4, both new vertices, their weights and their hard flags are unchanged. Nevertheless, C-agents can now take rows 1,3,5, of C-values 28,32,29, and R-agents take rows 2,4,6, each of R-value 28.

Thus the local numerical/hardness signature cannot determine global nonexistence. Adding all exterior winning traces makes the description exact, but makes it nonlocal. This does not prove that no more ingenious finite quotient exists; it establishes the missing information in the proposed elementary two-port state.

### 1.4 Corrected rigidity and the balanced cycle obstruction

A numerical correction matters. At n=5 the chain column weights are

    (19,23,23,24,23),

not (19,23,23,23,23). At n=6 they are (19,23,23,23,23,23); at n=7, (19,23,23,23,23,23,23).

Let E be the sum of row weight excesses above 22, D the sum of nonexceptional column excesses above 23, and z the exceptional column weight. For a case-R certificate of margin one,

    E = b-1,
    D+z = 22-a.

Indeed, summing the row weights gives S=22n+E; summing columns gives S=23(n-1)+D+z; the margin identity is S=22a+23b-1. The actual states are

| n | (a,b) | E | D | z |
|---|---|---|---|---|
| 5 | (2,3) | 2 | 1 | 19 |
| 6 | (3,3) | 2 | 0 | 19 |
| 7 | (3,4) | 3 | 0 | 19 |

The 5->6 step consumes the spare unit in c4. A new R-agent adds quota 22 and two new weights summing to 22; an ordinary column splits into two ordinary columns, so Wc+22 must be at least 46. This requires Wc>=24. The n=5 column c4 qualifies, but no ordinary column at n=7 does. The exceptional column is not subject to the same two-ordinary-column inequality; excluding those subdivisions needs additional arguments.

A balanced 7->9 return to the n=7 signature is impossible with fixed quotas (22,23), margin one, D=0 and z=19: the new split is (4,5), which would require D+z=18. Equivalently its margin would be zero. More generally D,z>=0 imply a<=22, excluding an indefinitely balanced family with those fixed quotas.

This proves an obstruction to that periodic induction, not the impossibility of every cycle after reweighting, changing branches, changing quotas, or adding only C-agents. No general periodic construction is established in this session.

## 2. Depth-two certificates: successful synthesis

### 2.1 Definition and LP

Fix goods p,q. A leaf ell=(ell_p,ell_q) in {R,C}^2 specifies their recipient types. Let F_t(ell) be the selected goods assigned to the opposite type. For that leaf choose nonnegative weights w^ell and quotas alpha_ell,beta_ell satisfying

    w^ell(S) >= alpha_ell for every R-winning S avoiding F_R(ell),
    w^ell(S) >= beta_ell  for every C-winning S avoiding F_C(ell),
    sum_g w^ell_g <= a alpha_ell + b beta_ell - 1.

An allocation consistent with the leaf would use more weight than exists. If all four leaves have such weights, no MMS allocation exists.

For a fixed instance and branch pair these are four LP feasibility problems. Minimal winning sets suffice, by nonnegative weights. Rational feasible weights can be multiplied by a common denominator. This is a certificate class: failure of a leaf LP does not imply an integral allocation. The LP relaxes a branch by forbidding opposite-type use; it does not require the selected goods to be used in its fractional solutions.

For jointly synthesising bounded integer valuations and weights, use a binary z_{t,S} and, for every applicable leaf, impose

    v_t(S) <= T-1 + M_v z_{t,S},
    w^ell(S) >= q^ell_t - M_w(1-z_{t,S}).

Here z=0 forces S to lose and z=1 activates its weight inequalities. Add the witness-partition equalities, positivity, explicit bounds, and any L1 constraints. M_v and M_w must dominate the chosen bounds. This is a finite exact MILP for the bounded integer model, not an unbounded-domain impossibility oracle.

For the nearby rational test we instead stayed in the tangent chamber of the supplied profile. Strictly winning/losing subset signs remain fixed under sufficiently small perturbations; only the 129 R-ties and 118 C-ties at T=26 require binary choices. Minimal strictly winning sets and the ties suffice to generate all potentially winning sets. The bounded model had 369 variables, including 247 binaries, and 3436 constraints. It solved at one branch-and-bound node. All conclusions below were then checked independently by exact arithmetic; solver tolerances are not part of the proof.

### 2.2 The supplied score-two profile

It has two compatible pairs of type-union masks, but 76 unordered pairs of minimal-bundle tuples: multiplicities 64 and 12. Representatives are:

* Row mode: R takes rows 2,4,6,8; C takes rows 1,3,5,7.
* Column mode: C takes columns 1,2,5,7; R takes {2,6}, {14,15}, {3,11,17}, {18,19}.

Both give g1 to C. Row mode gives g2 to C; column mode gives g2 to R. Thus g2 separates the modes under g1=C. At the unmodified profile this cannot certify infeasibility: each of those leaves contains an actual allocation. The nearby repair below removes the relevant ties.

### 2.3 Explicit new 8x19 instance

There are four R-agents and four C-agents. T=104.

    R = 28 57 19 36 5 63 15 89 36 5 63 93 11 43 61 85 19 43 61
    C = 31 47 23 36 3 61 15 93 37 4 61 97 11 43 56 89 25 43 57

The rows are the seven original rows followed by {18,19}. The columns are the seven original columns with c3 replaced by {2,19}, followed by c8={11,18}. Thus it is exactly the indicated subdivision of g11. Every row has R-value 104 and every column has C-value 104. Both total values are 832, proving MMS=104. All item values are positive and below 104. Hard rows are 3,5,7; hard columns are 3,6,8. Suppressing degree-two vertices gives the triangular prism, with none of the three core matching edges subdivided.

Branch on (g1,g2), with leaf letters denoting recipient types. Four exact weight vectors are:

    RR:  6 11  6  7 3 13  6 18  7 3 13 18  6 11 12 18  6 11 12
    RC:  2  4  2  3 1  5  2  7  3 1  5  7  2  4  5  7  2  4  5
    CR: 17 31 15 25 6 37 14 54 25 6 37 55 13 31 37 53 15 31 37
    CC: 15 26 13 22 5 33 12 48 22 5 33 49 11 27 33 47 13 27 33

| Leaf | alpha | beta | sum w | 4 alpha+4 beta | Margin | Checked min R/C weight |
|---|---|---|---|---|---|---|
| RR | 23 | 24 | 187 | 188 | 1 | 23 / 24 |
| RC | 9 | 9 | 71 | 72 | 1 | 9 / 9 |
| CR | 68 | 67 | 539 | 540 | 1 | 68 / 67 |
| CC | 60 | 59 | 474 | 476 | 2 | 60 / 59 |

Notice that equal quotas are possible in the mixed leaf RC: that leaf excludes a selected good from each type's bundle family. This does not contradict the original one-branch equal-quota impossibility, which uses the unrestricted row witness partition.

The standard-library checker `verify_new_certificate.py` checks all 2^19 subsets and all four leaves. The independent C++ packing checker found zero pairs at 104 and 56 unordered minimal-bundle tuple pairs at 103.

An allocation with minimum 103 is: R takes rows 2,4,6,8; C takes {3,8}, {12,13}, {7,16}, {1,2,17}. Its utilities are

    104,104,104,104 ; 116,108,104,103.

Consequently the exact best minimum is 103. This gives alpha_8<=103/104 and f(8)<=18. The ratio 103/104 is weaker than 26/27, so this does not improve the project's general approximation-ratio bound.

### 2.4 A continuous nearby family and its exact optimum

Let (R0,C0) be the supplied T=26 score-two profile and define

    hR =  0  1 -1 0  1 -1 -1 1 0 1 -1 1 -1 -1 1 1 -1 -1 1
    hC = -1 -1 -1 0 -1  1 -1 1 1 0  1 1 -1 -1 0 1  1 -1 1.

Set R(eps)=R0+eps*hR and C(eps)=C0+eps*hC. Every R-row and C-column directional sum is zero, so MMS remains 26. The same four weight vectors certify nonexistence for every

    0 < eps < 1/3.

Only four base ties are too light for their relevant leaf certificates:

| Type/set | Value after perturbation |
|---|---|
| R: {3,6,17} | 26-3 eps |
| R: {3,11,17} | 26-3 eps |
| C: {1,2,3} | 26-3 eps |
| C: {1,2,17} | 26-eps |

Every other allowed weight-deficient set stays below 26 throughout this interval. The first positive-eps obstruction to the displayed weights is the R-set {5,10,12}, of value 25+3 eps, at eps=1/3. These are exact subset checks, not sampled eps values.

In fact the exact max-min value is

    B(eps) = max(26-eps, 25+3 eps),  for 0<=eps<=1/3.

Proof of the upper bound: let H(eps) be the maximum value of any allowed weight-deficient set over all four leaves and both types. Any allocation with all utilities greater than H would contradict the weight budget in its leaf. Every such set's value is affine in eps. Exact endpoint checks give H(0)<=26, H(1/4)<=103/4 and H(1/3)<=26. Interpolation on [0,1/4] and [1/4,1/3] gives the claimed upper envelope.

Proof of the lower bound: allocation A above has utility affine pairs (intercept,slope)

    R: (26,0),(26,0),(26,0),(26,0)
    C: (29,0),(27,0),(26,0),(26,-1),

so its minimum is 26-eps. Allocation B gives R the sets {2,6}, {5,10,12}, {11,14}, {15,18}, and C the sets {1,4,9}, {8,13}, {7,16}, {3,17,19}. Its pairs are

    R: (30,0),(25,3),(27,-2),(26,0)
    C: (26,0),(26,0),(26,0),(26,1),

so its minimum is 25+3 eps throughout the interval. Both allocations are literal partitions of all 19 goods.

Thus eps=1/4 is optimal on this particular affine line and gives gap 1/104. For every integer K>=4, the integer profile (K R0+hR, K C0+hC), with T=26K, has exact best minimum 26K-1.

The joint L1 distance at the original normalization is 32 eps. Therefore bad rational instances occur in every neighbourhood of the score-two profile. The dossier's L1<=6 and L1<=20 exclusion statements cannot be interpreted over all rational or real valuations at fixed T=26. They may be valid on the fixed-T integer lattice; their original large searches and exact scope were not reverified here.

## 3. The invariant and the remaining conjecture

### 3.1 A fixed knapsack polyhedron, not a fixed winning hypergraph

For integer weights define

    K(w,q;F) = conv{1_S : S avoids F and w(S)<=q-1}.

For a fixed case-R weighting the valuation requirements are precisely

    max_{x in K(w,22;empty)} R.x <= T-1,
    max_{x in K(w,23;{g1})} C.x <= T-1.

Add the R-row and C-column witness equalities. The admissible valuations form a product of polyhedra. A valuation repair can change the winning hypergraphs while staying in these polyhedra: every set too light to meet the certificate quota remains losing. The persistence is of a separating weighting, not of the entire configuration family or of every knapsack envelope coordinate.

The exact checked support values are:

| n | T | max R-value at weight<=21 | max C-value at weight<=22, avoiding g1 |
|---|---|---|---|
| 5 | 29 | 28 | 28 |
| 6 | 28 | 27 | 27 |
| 7 | 27 | 26 | 26 |

The numbers of tight forbidden inequalities are respectively R: 5,8,13 and C: 6,13,12. The full capacity envelopes are retained in `invariants.json`; they are not identical after normalization by T.

### 3.2 Exact lifting recurrence

Let F_t(s) be the maximum t-value under weight capacity s, with g1 excluded for C. If p,q are the two new goods and the old goods have been repaired, then

    F_new,t(s) = max_{A subset {p,q}} [v_t(A)+F_repaired-old,t(s-w(A))],

with negative-capacity terms omitted. This is an exact four-term knapsack recurrence, not a heuristic.

At the relevant capacities (21 for R, 22 for C), the terms indexed by empty,p,q,pq are:

| Transition | R terms | C terms |
|---|---|---|
| 5->6 | (27,21,27,-infinity) | (27,24,27,27) |
| 6->7 | (26,23,23,-infinity) | (26,24,24,-infinity) |

Thus the weight-deficient supports remain exactly T_new-1. In 6->7, in particular, the new goods do not create a larger obstruction than the repaired prefix. This explains the unchanged chain weights precisely; it does not supply the missing uniform rule producing the repairs.

The 8-agent construction uses the same principle leaf by leaf. Its rational perturbation moves a few tied, weight-deficient subsets strictly to the losing side. The integer search at one threshold misses this continuous direction.

### 3.3 A clean all-n conjecture

**Balanced-prism, depth-two conjecture.** For every n>=4 there is a connected bipartite subdivision of the triangular prism, with n row vertices, n column vertices, 2n+3 goods and unsubdivided core matching edges, supporting positive rational two-type valuations with split (floor(n/2),ceil(n/2)), exact R-row and C-column witness partitions, and a valid depth-at-most-two recipient-type weighting certificate.

The accepted n=4,5,6,7 examples and the n=8 example here satisfy these conditions. An eventual proof would imply f(n)<=2n+2 throughout this range. This conjecture deliberately does not fix quotas 22,23, a fixed integer threshold, or unchanged prefix weights: those restrictions already have obstructions.

To turn this into an inductive theorem one still needs a closed lifting rule: after subdivision and repair, each leaf's forbidden-knapsack support must remain below T while its weight budget retains positive margin. No such uniform lifting rule has been proved here.

A single n for which no permitted prism subdivision admits a depth-two-certified profile would refute this conjecture. A proof that all profiles on those subdivisions admit MMS allocations would refute even its certificate-free existence version. Failure on one edge, one fixed weight prefix, one bounded integer box, or one particular repair direction does not suffice. Nor does the failure of a fixed-(22,23) balanced cycle refute the flexible conjecture.

## Files and trust boundary

* `8x19_depth2.json`: new instance, witness partitions, four integer certificates and optimal allocation.
* `verify_new_certificate.py`: standalone standard-library verifier, including the exact continuous-family theorem.
* `logs/13_standalone_verification.txt`: its complete output.
* `scripts/04_profile_packings.cpp`: independent exact packing checker, adapted from the supplied code, with explicit state/tuple guards.
* `logs/04_profile_packings.json`: the supplied profile's two union modes and multiplicities.
* `logs/08_depth2_packings_T104.json`, `logs/09_depth2_packings_B103.json`: independent packing results for the new example.
* `gadget_signatures.json`, `audit.json`, `invariants.json`: exact finite signature and invariant checks.
* `scripts/05_leaf_lps.py`, `scripts/06_nearby_direction.py`, `nearby_direction.json`: synthesis and bounded-search provenance.
* `REPRODUCE.md`, `MANIFEST.sha256`: commands, environment and hashes.

The proofs of the new instance and parametric family depend on finite integer arithmetic and the displayed weight-budget argument, not on the correctness of the optimiser.
