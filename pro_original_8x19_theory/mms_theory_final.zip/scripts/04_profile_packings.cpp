// Exact check of one supplied profile, not a search. Adapted from supplied packing_pairs.cpp.
// Guard: at most 100,000,000 recursive states and 10,000,000 tuples per type.
#include <bits/stdc++.h>
using namespace std;
using ull=unsigned long long;
int m,full;
vector<int> minimal_sets(const vector<int>& v,int q){
 vector<int>s(1<<m);for(int a=1;a<=full;a++){int l=a&-a;s[a]=s[a^l]+v[__builtin_ctz((unsigned)l)];}
 vector<int>out;for(int a=1;a<=full;a++)if(s[a]>=q){bool good=true;for(int x=a;x;x&=x-1)if(s[a^(x&-x)]>=q){good=false;break;}if(good)out.push_back(a);}return out;
}
struct Counts{vector<ull> c; vector<array<int,4>> witness;ull tuples=0,nodes=0;Counts():c(1<<m),witness(1<<m){} };
void rec(const vector<int>&s,int k,int start,int mask,int d,array<int,4>&w,Counts&out){
 if(++out.nodes>100000000)throw runtime_error("NODE GUARD");
 if(d==k){if(++out.tuples>10000000)throw runtime_error("TUPLE GUARD");if(!out.c[mask])out.witness[mask]=w;out.c[mask]++;return;}
 for(int i=start;i<(int)s.size();i++)if(!(s[i]&mask)){w[d]=s[i];rec(s,k,i+1,mask|s[i],d+1,w,out);}
}
void printmask(int mask){cout<<"[";bool sep=false;for(int j=0;j<m;j++)if(mask>>j&1){if(sep)cout<<",";cout<<j+1;sep=true;}cout<<"]";}
int main(){try{int a,b,q;cin>>m>>a>>b>>q;if(m>19||a>4||b>4)throw runtime_error("INPUT GUARD");full=(1<<m)-1;vector<int>R(m),C(m);for(int&x:R)cin>>x;for(int&x:C)cin>>x;auto rs=minimal_sets(R,q),cs=minimal_sets(C,q);Counts cr,cc;array<int,4>w{};rec(rs,a,0,0,0,w,cr);rec(cs,b,0,0,0,w,cc);
 vector<ull>z=cc.c;for(int j=0;j<m;j++)for(int s=0;s<=full;s++)if(s>>j&1)z[s]+=z[s^(1<<j)];ull pairs=0;int ur=0,uc=0;for(int s=0;s<=full;s++){if(cr.c[s]){ur++;pairs+=cr.c[s]*z[full^s];}if(cc.c[s])uc++;}
 cout<<"{\"minimal_R\":"<<rs.size()<<",\"minimal_C\":"<<cs.size()<<",\"R_tuples\":"<<cr.tuples<<",\"C_tuples\":"<<cc.tuples<<",\"R_unions\":"<<ur<<",\"C_unions\":"<<uc<<",\"tuple_pairs\":"<<pairs<<",\"R_nodes\":"<<cr.nodes<<",\"C_nodes\":"<<cc.nodes<<",\"packings\":[";
 bool comma=false;for(int s=0;s<=full;s++)if(cr.c[s]&&z[full^s]){int comp=full^s;for(int t=comp;;t=(t-1)&comp){if(cc.c[t]){if(comma)cout<<",";comma=true;cout<<"{\"R\":[";for(int i=0;i<a;i++){if(i)cout<<",";printmask(cr.witness[s][i]);}cout<<"],\"C\":[";for(int i=0;i<b;i++){if(i)cout<<",";printmask(cc.witness[t][i]);}cout<<"],\"multiplicity\":"<<cr.c[s]*cc.c[t]<<"}";}if(!t)break;}}
 cout<<"]}\n";
 }catch(exception&e){cerr<<e.what()<<"\n";return 2;}}
