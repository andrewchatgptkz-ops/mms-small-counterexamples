"""Small, guarded tangent-chamber test; no valuation/pattern enumeration.
A feasible direction can be scaled arbitrarily small, keeping all strictly
winning/losing subset signs fixed. Both witness partitions are preserved.
The MILP is explicitly bounded; an unsuccessful run is NOT a global no-go.
"""
from pathlib import Path
import json,itertools
import numpy as np
from scipy.optimize import linprog,milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
P=Path('/mnt/data/mms_theory');d=json.loads((P/'8x19_score2.json').read_text())
fam=json.loads((P/'profile_families.json').read_text());lp=json.loads((P/'leaf_lps.json').read_text())
m=19;leaves=['RR','RC','CR','CC']; types=['R','C']
def bits(s):return [j for j in range(m) if s>>j&1]
def allowed(s,t,leaf):return not any((s>>j&1) and leaf[j]!=t for j in [0,1])
E=[]
for ti,t in enumerate(types):
 for s in d['rows_R_sum_T' if t=='R' else 'cols_C_sum_T']:
  row=np.zeros(2*m)
  for g in s:row[ti*m+g-1]=1
  E.append(row)
E=np.array(E)
rows=[];required=[]
for ti,t in enumerate(types):
 for s in fam[t]['ties']:
  bad=[]
  for leaf in leaves:
   if not allowed(s,t,leaf):continue
   w=lp['forced_'+leaf]['x']
   if sum(w[j] for j in bits(s))<w[m+ti]-1e-6:bad.append(leaf)
  if bad:
   row=np.zeros(2*m);row[[ti*m+j for j in bits(s)]]=1;rows.append(row)
   required.append({'type':t,'set':[j+1 for j in bits(s)],'leaves':bad})
r=linprog(np.zeros(2*m),A_ub=np.array(rows),b_ub=-np.ones(len(rows)),A_eq=E,b_eq=np.zeros(len(E)),bounds=[(None,None)]*(2*m),method='highs')
ans={'fixed_weights_direction_LP':{'status':int(r.status),'message':r.message,'required_deletions':required,'x':None if r.x is None else r.x.tolist()}}
print('Fixed forced-LP weights: direction feasibility status',r.status,'required deletions',len(rows),flush=True)
if r.success:
 (P/'nearby_direction.json').write_text(json.dumps(ans,indent=2)+'\n');print('Found fixed-weight direction.',flush=True);raise SystemExit

# Joint bounded synthesis: 247 tie-selector binaries, 38 directional variables,
# 84 nonnegative weight/quota variables. Bounds are part of the tested claim.
D=8.;W=256.; node_limit=32
pairs=[(t,s) for t in types for s in fam[t]['ties']]
zidx={p:2*m+i for i,p in enumerate(pairs)}
off=2*m+len(pairs);N=off+len(leaves)*(m+2)
lower=np.zeros(N);upper=np.ones(N);lower[:2*m]=-D;upper[:2*m]=D;upper[off:]=W
integrality=np.zeros(N,dtype=int);integrality[2*m:off]=1
rr=[];cc=[];vv=[];lo=[];hi=[]
def add(co,ub=np.inf,lb=-np.inf):
 i=len(hi)
 for j,v in co.items():
  if v:rr.append(i);cc.append(j);vv.append(v)
 hi.append(ub);lo.append(lb)
for row in E:add({j:v for j,v in enumerate(row) if v},0,0)
for t,s in pairs:
 ti=types.index(t);js=bits(s);co={ti*m+j:1 for j in js};co[zidx[t,s]]=D*len(js)+1
 add(co,D*len(js))
for li,leaf in enumerate(leaves):
 start=off+li*(m+2)
 co={start+j:1 for j in range(m)};co[start+m]=-4;co[start+m+1]=-4;add(co,-1)
 for ti,t in enumerate(types):
  for s in fam[t]['strict']:
   if not allowed(s,t,leaf):continue
   co={start+j:-1 for j in bits(s)};co[start+m+ti]=1;add(co,0)
  for s in fam[t]['ties']:
   if not allowed(s,t,leaf):continue
   co={start+j:-1 for j in bits(s)};co[start+m+ti]=1;co[zidx[t,s]]=-W;add(co,0)
A=coo_matrix((vv,(rr,cc)),shape=(len(hi),N)).tocsc()
objective=np.zeros(N);objective[2*m:off]=1 # prefer fewer deleted ties
print('Bounded joint MILP:',N,'variables;',len(pairs),'binary;',len(hi),'constraints; node_limit=',node_limit,flush=True)
r=milp(objective,integrality=integrality,bounds=Bounds(lower,upper),constraints=LinearConstraint(A,np.array(lo),np.array(hi)),options={'node_limit':node_limit,'mip_rel_gap':0.0,'disp':False})
rec={'status':int(r.status),'message':r.message,'D':D,'W':W,'node_limit':node_limit,'nodes':getattr(r,'mip_node_count',None),'fun':None if r.fun is None else float(r.fun),'x':None if r.x is None else r.x.tolist()}
ans['joint_bounded_MILP']=rec
if r.x is not None:
 rec['direction_R']=r.x[:m].tolist();rec['direction_C']=r.x[m:2*m].tolist()
 rec['weights']={leaf:r.x[off+li*(m+2):off+(li+1)*(m+2)].tolist() for li,leaf in enumerate(leaves)}
 rec['deleted_ties']=[{'type':t,'set':[j+1 for j in bits(s)]} for (t,s),j in zidx.items() if r.x[j]>.5]
 print('FEASIBLE CANDIDATE; exact verification required.',flush=True)
print('MILP status',r.status,r.message,'nodes',getattr(r,'mip_node_count',None),flush=True)
(P/'nearby_direction.json').write_text(json.dumps(ans,indent=2)+'\n')
