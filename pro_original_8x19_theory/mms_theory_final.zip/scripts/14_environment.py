import sys,platform,subprocess,hashlib
from pathlib import Path
import numpy,scipy,networkx
print('Python',sys.version)
print('Platform',platform.platform())
print('NumPy',numpy.__version__,'SciPy',scipy.__version__,'NetworkX',networkx.__version__)
print(subprocess.run(['g++','--version'],capture_output=True,text=True,check=True).stdout)
p=Path('/mnt/data/mms_kit_v3(2).zip')
print('Input SHA256',hashlib.sha256(p.read_bytes()).hexdigest(),p.name)
