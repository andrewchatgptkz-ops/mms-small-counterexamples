from pathlib import Path
import zipfile, hashlib
root=Path('/mnt/data/mms_theory')
with zipfile.ZipFile('/mnt/data/mms_kit_v3(2).zip') as z: z.extractall(root/'input')
with zipfile.ZipFile(root/'input/mms-two-type-counterexamples.zip') as z: z.extractall(root/'repo')
(root/'REPORT.md').write_text('# MMS theory session\n\nInitial snapshot: supplied dossier read in full, including section 8. No mathematical conclusions yet.\n')
(root/'REPRODUCE.md').write_text('# Reproduction\n\nInitial archive: `/mnt/data/mms_kit_v3(2).zip`.\n\n`python scripts/00_restore.py` restores the two supplied archives.\n')
(root/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in sorted(root.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256'))
with zipfile.ZipFile('/mnt/data/mms_theory_stage0.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file(): z.write(p,p.relative_to(root))
print('Initial snapshot saved.')
for p in sorted((root/'repo').rglob('*')):
 if p.is_file(): print(p.relative_to(root),p.stat().st_size)
