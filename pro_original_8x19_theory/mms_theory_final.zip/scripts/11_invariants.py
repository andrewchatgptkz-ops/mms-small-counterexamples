from pathlib import Path
from fractions import Fraction
import json
import numpy as np
P=Path('/mnt/data/mms_theory');I=P/'repo/mms-two-type-counterexamples/instances'
w=[5,11,6,7,3,12,6,17,7,3,12,17,6,11,11,17,6]
def ss(v):
 s=np.zeros(1<<len(v),dtype=np.int64)
 for j,x in enumerate(v):s[1<<j:1<<(j+1)]=s[:1<<j]+x
 return s
def envelope(v,weights,cap,avoid_first=False):
 vs=ss(v);ws=ss(weights);masks=np.arange(len(vs));allow=(masks&1)==0 if avoid_first else np.ones(len(vs),dtype=bool)
 return [int(vs[(ws<=j)&allow].max()) for j in range(cap+1)]
out={}
for n,m in [(5,13),(6,15),(7,17)]:
 d=json.loads((I/f'{n}x{m}.json').read_text());T=d['T'];ws=w[:m];a=n//2;b=n-a
 rw=[sum(ws[g-1] for g in row) for row in d['rows_R_sum_T']]
 cw=[sum(ws[g-1] for g in col) for col in d['cols_C_sum_T']]
 E=sum(x-22 for x in rw);D=sum(x-23 for x in cw[1:]);z=cw[0]
 assert E==b-1 and D+z==22-a
 rec={'E_row_excess':E,'D_ordinary_column_excess':D,'z_exceptional_column':z}
 print(n,'E,D,z=',E,D,z,'a,b=',a,b)
 for typ,cap in [('R',21),('C',22)]:
  F=envelope(d[typ],ws,cap,typ=='C');rec['F_'+typ]=F;rec['D_'+typ]=[T-x for x in F]
  print(' ',typ,'F[0..'+str(cap)+'] =',F)
  print(' ',typ,'T-F =',rec['D_'+typ])
 if n>5:
  oldm=m-2;terms={}
  for typ,cap in [('R',21),('C',22)]:
   Fold=envelope(d[typ][:oldm],ws[:oldm],cap,typ=='C');vnew=d[typ][-2:];wnew=ws[-2:];values=[]
   for mask in range(4):
    used=sum(wnew[j] for j in range(2) if mask>>j&1)
    val=sum(vnew[j] for j in range(2) if mask>>j&1)
    values.append(None if used>cap else val+Fold[cap-used])
   assert max(x for x in values if x is not None)==rec['F_'+typ][-1]
   terms[typ]=values
  rec['lift_terms_empty_p_q_pq']=terms
  print('  repaired-prefix lift terms empty,p,q,pq:',terms)
 out[str(n)]=rec
# Prove the exact max-min envelope for the nearby 8-agent family using endpoints.
d=json.loads((P/'8x19_depth2.json').read_text());base=json.loads((P/'8x19_score2.json').read_text());m=19;masks=np.arange(1<<m);checks=[]
for leaf,c in d['certificates'].items():
 ws=ss(c['w'])
 for typ,q in [('R',c['alpha']),('C',c['beta'])]:
  forbidden=sum(1<<j for j,l in enumerate(leaf) if l!=typ)
  poor=((masks&forbidden)==0)&(ws<q)
  vs=ss(base[typ]);hs=ss(d['direction_'+typ])
  maxima=[]
  for num,den,bound in [(0,1,26),(1,4,103),(1,3,78)]:
   mx=int((den*vs+num*hs)[poor].max());assert mx<=bound;maxima.append([num,den,mx,bound])
  checks.append({'leaf':leaf,'type':typ,'endpoint_maxima':maxima})
  print('Parametric upper-envelope check',leaf,typ,maxima)
A={'R':[[4,5,6],[9,10,11],[14,15],[18,19]],'C':[[3,8],[12,13],[7,16],[1,2,17]]}
B={'R':[[2,6],[5,10,12],[11,14],[15,18]],'C':[[1,4,9],[8,13],[7,16],[3,17,19]]}
for label,alloc in [('A',A),('B',B)]:
 assert sorted(g for t in ['R','C'] for S in alloc[t] for g in S)==list(range(1,20))
 coeffs={t:[[sum(base[t][g-1] for g in S),sum(d['direction_'+t][g-1] for g in S)] for S in alloc[t]] for t in ['R','C']}
 print('Allocation',label,'utility coefficients intercept,slope:',coeffs)
 # On the interval [0,1/3], A achieves 26-eps, B achieves 25+3eps.
 intercept,slope=(26,-1) if label=='A' else (25,3)
 for t in ['R','C']:
  for u,v in coeffs[t]:
   assert u>=intercept and 3*u+v>=3*intercept+slope
 assert [intercept,slope] in coeffs['R']+coeffs['C']
 out['allocation_'+label]={'bundles':alloc,'utility_coefficients':coeffs}
out['parametric_upper_envelope_checks']=checks
out['exact_best_min']='max(26-epsilon,25+3*epsilon), 0<=epsilon<=1/3'
# Check the displayed T=104 allocation and retain exact certificate minima.
util={t:[sum(d[t][g-1] for g in S) for S in A[t]] for t in ['R','C']};assert min(util['R']+util['C'])==103
print('T104 allocation A utilities:',util)
d.update(MMS=[104]*8,best_min=103,ratio='103/104',best_allocation_1based=A['R']+A['C'],best_allocation_utilities=util['R']+util['C'])
(P/'8x19_depth2.json').write_text(json.dumps(d,indent=2)+'\n')
(P/'invariants.json').write_text(json.dumps(out,indent=2)+'\n')
print('PROVED: B(eps)=max(26-eps,25+3eps) on [0,1/3]. Best gap within this line = 1/104 at eps=1/4.')
