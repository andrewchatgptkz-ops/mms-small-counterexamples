from pathlib import Path
import json,networkx as nx
P=Path('/mnt/data/mms_theory');I=P/'repo/mms-two-type-counterexamples/instances'
for name in ['4x11','5x13','6x15','7x17','8x19_depth2']:
 d=json.loads(((P/f'{name}.json') if name=='8x19_depth2' else I/f'{name}.json').read_text())
 G=nx.Graph();loc={g:('c',i) for i,col in enumerate(d['cols_C_sum_T'],1) for g in col}
 for i,row in enumerate(d['rows_R_sum_T'],1):
  for g in row:G.add_edge(('r',i),loc[g],g=g)
 assert nx.is_connected(G) and all(deg in [2,3] for _,deg in G.degree())
 core=[v for v in G if G.degree(v)==3];assert len(core)==6;H=nx.Graph();paths={}
 for u in core:
  for v in G[u]:
   prev=u;now=v;path=[G.edges[u,v]['g']]
   while now not in core:
    nxt=next(x for x in G[now] if x!=prev);path.append(G.edges[now,nxt]['g']);prev,now=now,nxt
   key=tuple(sorted([u,now]));H.add_edge(u,now);paths[key]=path
 assert H.number_of_edges()==9 and nx.is_isomorphic(H,nx.circular_ladder_graph(3))
 matching=[(key,p) for key,p in paths.items() if not(set(H[key[0]])&set(H[key[1]]))]
 assert len(matching)==3 and all(len(p)==1 for _,p in matching)
 print(name,'vertices',G.number_of_nodes(),'edges',G.number_of_edges(),'prism core verified; matching edges not subdivided; core paths',list(paths.values()))
