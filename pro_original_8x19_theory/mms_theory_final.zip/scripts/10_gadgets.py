from pathlib import Path
import json,itertools
import numpy as np
P=Path('/mnt/data/mms_theory');I=P/'repo/mms-two-type-counterexamples/instances'
W=[5,11,6,7,3,12,6,17,7,3,12,17,6,11,11,17,6]
def ss(v):
 a=np.zeros(1<<len(v),dtype=np.int64)
 for j,x in enumerate(v):a[1<<j:1<<(j+1)]=a[:1<<j]+x
 return a
def goods(s,m):return [j+1 for j in range(m) if s>>j&1]
def minimal(v,T):
 s=ss(v);m=len(v);mask=np.arange(1<<m);ok=s>=T
 for j,x in enumerate(v):ok &= (((mask>>j)&1)==0)|(s-x<T)
 return [int(x) for x in mask[ok]]
def partitions(items):
 if not items:yield [];return
 x=items[0]
 for p in partitions(items[1:]):
  yield [[x]]+[b[:] for b in p]
  for i in range(len(p)):
   q=[b[:] for b in p];q[i].append(x);yield q
out={}
for name,n,m,G,oldrow,oldcol,newrow,newcol in [
 ('4to5_A',5,13,[8,13,12],3,2,5,5),
 ('4to5_B',5,13,[13,8,7],5,4,3,5),
 ('5to6',6,15,[6,14,15],2,4,6,6),
 ('6to7',7,17,[7,16,17],3,4,7,7)]:
 d=json.loads((I/f'{n}x{m}.json').read_text());T=d['T'];w=W[:m]
 sig={'name':name,'instance':d['name'],'goods_order_xyz':G,'T':T,'R_G':[d['R'][g-1] for g in G],'C_G':[d['C'][g-1] for g in G],'w_G':[w[g-1] for g in G]}
 for label,j,key,t,wt in [('old_row',oldrow,'rows_R_sum_T','C',22),('old_col',oldcol,'cols_C_sum_T','R',23),('new_row',newrow,'rows_R_sum_T','C',22),('new_col',newcol,'cols_C_sum_T','R',23)]:
  block=d[key][j-1];v=sum(d[t][g-1] for g in block)
  sig[label]={'index':j,'goods':block,'cross_value':v,'hard':v>=T,'weight':sum(w[g-1] for g in block)}
 sig['subset_signatures']=[]
 for mask in range(8):
  U=[G[j] for j in range(3) if mask>>j&1]
  sig['subset_signatures'].append({'mask':mask,'goods':U,'port_mask':mask&5,'R_deficit':max(0,T-sum(d['R'][g-1] for g in U)),'C_deficit':max(0,T-sum(d['C'][g-1] for g in U)),'weight':sum(w[g-1] for g in U)})
 trace={};counts={};locals={}
 for t in ['R','C']:
  wins=minimal(d[t],T)
  # Unrestricted actual minimal winning sets; all exterior remainders are saved.
  trace[t]={str(i):[] for i in range(8)}
  for S in wins:
   k=sum(1<<j for j,g in enumerate(G) if S>>(g-1)&1)
   trace[t][str(k)].append(goods(S,m))
  counts[t]=[len(trace[t][str(i)]) for i in range(8)]
  locals[t]=[goods(s,3) for s in minimal(sig[t+'_G'],T)]
 sig['trace_counts']=counts;sig['winning_traces']=trace;sig['internal_minimal_winners_xyz_indices']=locals
 transfers=[]
 for used in range(8):
  for partition in partitions([j for j in range(3) if used>>j&1]):
   for types in itertools.product('RC',repeat=len(partition)):
    blocks=[]
    for block,t in zip(partition,types):
     v=sum(sig[t+'_G'][j] for j in block)
     blocks.append({'type':t,'local_indices':[j+1 for j in sorted(block)],'deficit':max(0,T-v),'weight':sum(sig['w_G'][j] for j in block)})
    transfers.append({'used_mask':used,'blocks':blocks})
 assert len(transfers)==47 and sum(z['used_mask']==7 for z in transfers)==22
 sig['all_partial_typed_transfers']=transfers
 print(name,'G=',G,'R=',sig['R_G'],'C=',sig['C_G'],'w=',sig['w_G'])
 print('  local minimal winners x=1,y=2,z=3:',locals)
 print('  hard(old row,old col,new row,new col)=',[sig[k]['hard'] for k in ['old_row','old_col','new_row','new_col']])
 print('  weight(old row,old col,new row,new col)=',[sig[k]['weight'] for k in ['old_row','old_col','new_row','new_col']])
 print('  trace counts in mask order 0,x,y,xy,z,xz,yz,xyz:',counts)
 out[name]=sig
# Concrete nonlocality witness, preserving all data at both ports of the 5->6 gadget.
d=json.loads((I/'6x15.json').read_text());e=json.loads(json.dumps(d));e['C'][1]+=2;e['C'][10]-=2
assert all(sum(e['C'][g-1] for g in c)==28 for c in e['cols_C_sum_T'])
localgoods=set([6,14,15]+d['rows_R_sum_T'][1]+d['cols_C_sum_T'][3])
assert all(e[t][g-1]==d[t][g-1] for t in ['R','C'] for g in localgoods)
allocR=[e['rows_R_sum_T'][j-1] for j in [2,4,6]];allocC=[e['rows_R_sum_T'][j-1] for j in [1,3,5]]
uR=[sum(e['R'][g-1] for g in s) for s in allocR];uC=[sum(e['C'][g-1] for g in s) for s in allocC]
assert min(uR+uC)>=28
out['nonlocality_witness']={'change_C':{'g2':2,'g11':-2},'unchanged_local_goods':sorted(localgoods),'R_allocation':allocR,'C_allocation':allocC,'utilities_R':uR,'utilities_C':uC}
print('NONLOCALITY: C2+=2,C11-=2, local goods unchanged:',sorted(localgoods),'R utilities',uR,'C utilities',uC)
# A winning bundle can touch only the internal middle edge, not either end edge.
S=[11,14];assert set(S)&{6,14,15}=={14}
vals=[sum(d[t][g-1] for g in S) for t in ['R','C']];assert min(vals)>=28
print('Middle-only crossing winning set {11,14}: R,C=',vals)
(P/'gadget_signatures.json').write_text(json.dumps(out,indent=2)+'\n')
