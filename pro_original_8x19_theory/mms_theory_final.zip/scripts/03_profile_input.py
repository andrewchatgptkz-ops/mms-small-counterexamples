import json
from pathlib import Path
P=Path('/mnt/data/mms_theory')
d=json.loads((P/'repo/mms-two-type-counterexamples/instances/7x17.json').read_text())
d.update(name='8x19-score2',agents=8,goods=19,T=26,a=4,b=4,
 R=[7,14,5,9,1,16,4,22,9,1,16,23,3,11,15,21,5,11,15],
 C=[8,12,6,9,1,15,4,23,9,1,15,24,3,11,14,22,6,11,14])
for k in ['MMS','best_min','ratio','best_allocation_1based','best_allocation_utilities','found_by','status','split']: d.pop(k,None)
d['rows_R_sum_T'].append([18,19]);d['cols_C_sum_T'][2]=[2,19];d['cols_C_sum_T'].append([11,18])
assert all(sum(d['R'][g-1] for g in row)==26 for row in d['rows_R_sum_T'])
assert all(sum(d['C'][g-1] for g in col)==26 for col in d['cols_C_sum_T'])
(P/'8x19_score2.json').write_text(json.dumps(d,indent=2)+'\n')
(P/'8x19_input.txt').write_text('19 4 4 26\n'+' '.join(map(str,d['R']))+'\n'+' '.join(map(str,d['C']))+'\n')
print('8x19: both witness partitions sum exactly to 26.')
print('C(row):',[sum(d['C'][g-1] for g in row) for row in d['rows_R_sum_T']])
print('R(col):',[sum(d['R'][g-1] for g in col) for col in d['cols_C_sum_T']])
