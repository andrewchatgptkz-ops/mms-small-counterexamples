"""Exact integer/rational verification of the guarded MILP candidate.
No solver is on the trusted path of the conclusions produced by this file.
"""
from pathlib import Path
from fractions import Fraction
from math import lcm,gcd
from functools import reduce
import json
import numpy as np
P=Path('/mnt/data/mms_theory');base=json.loads((P/'8x19_score2.json').read_text())
raw=json.loads((P/'nearby_direction.json').read_text())['joint_bounded_MILP'];m=19;N=1<<m;masks=np.arange(N,dtype=np.int64)
def sums(v):
 s=np.zeros(N,dtype=np.int64)
 for j,x in enumerate(v):s[1<<j:1<<(j+1)]=s[:1<<j]+x
 return s
def ints(v):
 fr=[Fraction(float(x)).limit_denominator(10000) for x in v]
 den=lcm(*(x.denominator for x in fr));out=[int(x*den) for x in fr]
 return out,den
def gs(s):return [j+1 for j in range(m) if s>>j&1]
h,den=ints(raw['direction_R']+raw['direction_C']);factor=reduce(gcd,(abs(x) for x in h));h=[x//factor for x in h]
hR,hC=h[:m],h[m:]
for typ,hv,key in [('R',hR,'rows_R_sum_T'),('C',hC,'cols_C_sum_T')]:
 assert all(sum(hv[g-1] for g in block)==0 for block in base[key])
print('hR =',hR);print('hC =',hC)
cert={}
for leaf,x in raw['weights'].items():
 iv,_=ints(x);factor=reduce(gcd,iv);iv=[z//factor for z in iv]
 cert[leaf]={'w':iv[:m],'alpha':iv[m],'beta':iv[m+1]}
vals={t:sums(base[t]) for t in ['R','C']};ds={'R':sums(hR),'C':sums(hC)}
limits=[]
for leaf,c in cert.items():
 ws=sums(c['w']);margin=4*c['alpha']+4*c['beta']-sum(c['w']);assert margin>=1;c['margin']=margin
 print('leaf',leaf,'alpha beta',c['alpha'],c['beta'],'sum',sum(c['w']),'margin',margin,'w',c['w'])
 for t,q in [('R',c['alpha']),('C',c['beta'])]:
  forbidden=sum(1<<j for j,l in enumerate(leaf) if l!=t)
  poor=((masks&forbidden)==0)&(ws<q)
  assert np.all(vals[t][poor]<=26)
  tie=poor&(vals[t]==26)
  assert np.all(ds[t][tie]<0)
  rising=poor&(ds[t]>0)
  indices=masks[rising]
  lim=min((Fraction(26-int(vals[t][s]),int(ds[t][s])),int(s)) for s in indices)
  limits.append((lim[0],leaf,t,lim[1]))
  print(' ',t,'poor ties',[gs(int(s)) for s in masks[tie]],'first positive epsilon obstruction',str(lim[0]),gs(lim[1]))
maxeps=min(x[0] for x in limits)
print('All four leaf certificates valid for every 0 < epsilon <',maxeps)
# Use a small denominator strictly inside the exact admissible interval.
K=next(k for k in range(1,10000) if Fraction(1,k)<maxeps)
new={**base,'name':f'8x19-depth2-T{26*K}','T':26*K,'R':[K*x+y for x,y in zip(base['R'],hR)],'C':[K*x+y for x,y in zip(base['C'],hC)],'direction_R':hR,'direction_C':hC,'scaling_K':K,'branch_goods':[1,2],'certificates':cert}
assert all(0<x<new['T'] for t in ['R','C'] for x in new[t])
for typ,key in [('R','rows_R_sum_T'),('C','cols_C_sum_T')]:
 assert all(sum(new[typ][g-1] for g in block)==new['T'] for block in new[key])
sv={t:sums(new[t]) for t in ['R','C']}
for leaf,c in cert.items():
 ws=sums(c['w'])
 mins=[]
 for t,q in [('R',c['alpha']),('C',c['beta'])]:
  forbidden=sum(1<<j for j,l in enumerate(leaf) if l!=t)
  win=((masks&forbidden)==0)&(sv[t]>=new['T'])
  mn=int(ws[win].min());assert mn>=q;mins.append(mn)
 c['checked_min_R'],c['checked_min_C']=mins
 print('EXACT VERIFIED',leaf,'minimum weights',mins,'margin',c['margin'])
print('NEW INSTANCE T=',new['T']);print('R=',new['R']);print('C=',new['C'])
(P/'8x19_depth2.json').write_text(json.dumps(new,indent=2)+'\n')
(P/'nearby_exact.json').write_text(json.dumps({'hR':hR,'hC':hC,'epsilon_upper_exclusive':str(maxeps),'limits':[{'epsilon':str(v),'leaf':l,'type':t,'set':gs(s)} for v,l,t,s in limits],'K':K},indent=2)+'\n')
(P/'8x19_depth2_input.txt').write_text(f'19 4 4 {new["T"]}\n'+' '.join(map(str,new['R']))+'\n'+' '.join(map(str,new['C']))+'\n')
