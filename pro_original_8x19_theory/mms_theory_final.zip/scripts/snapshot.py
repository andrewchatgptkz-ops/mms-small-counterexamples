from pathlib import Path
import hashlib, zipfile,sys
P=Path('/mnt/data/mms_theory')
files=[p for p in sorted(P.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in str(p)]
(P/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(P))+'\n' for p in files))
name=sys.argv[1] if len(sys.argv)>1 else 'mms_theory_latest.zip'
with zipfile.ZipFile(P.parent/name,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[P/'MANIFEST.sha256']:z.write(p,p.relative_to(P))
print(name,hashlib.sha256((P.parent/name).read_bytes()).hexdigest())
