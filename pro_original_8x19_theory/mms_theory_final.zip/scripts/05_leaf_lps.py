from pathlib import Path
import json,itertools
import numpy as np
from scipy.optimize import linprog
P=Path('/mnt/data/mms_theory')
d=json.loads((P/'8x19_score2.json').read_text());m=19;T=26;N=1<<m; masks=np.arange(N,dtype=np.int64)
def ss(v):
 a=np.zeros(N,dtype=np.int64)
 for j,x in enumerate(v):a[1<<j:1<<(j+1)]=a[:1<<j]+x
 return a
def minimal(v,q):
 s=ss(v); yes=s>=q
 for j,x in enumerate(v):yes &= (((masks>>j)&1)==0)|(s-x<q)
 return [int(s) for s in masks[yes]]
def mask(gs):return sum(1<<(j-1) for j in gs)
results={}; allfamilies={}
for typ in ['R','C']:
 a=minimal(d[typ],T);strict=minimal(d[typ],T+1)
 witness=[mask(s) for s in d['rows_R_sum_T' if typ=='R' else 'cols_C_sum_T']]
 allfamilies[typ]=dict(ordinary=a,forced=sorted(set(strict+witness)),strict=strict,ties=[int(s) for s in masks[ss(d[typ])==T]])
 print(typ,'minimal',len(a),'minimal strict',len(strict),'ties',len(allfamilies[typ]['ties']))

for mode in ['ordinary','forced']:
 for labels in itertools.product('RC',repeat=2):
  leaf=''.join(labels); rows=[]
  for ti,t in enumerate(['R','C']):
   forbid=sum(1<<j for j,l in enumerate(labels) if l!=t)
   for s in allfamilies[t][mode]:
    if s&forbid:continue
    r=np.zeros(m+2)
    for j in range(m):
     if s>>j&1:r[j]=-1
    r[m+ti]=1;rows.append(r)
  r=np.ones(m+2);r[-2:]=[-4,-4];rows.append(r)
  rhs=np.zeros(len(rows));rhs[-1]=-1
  z=linprog(np.zeros(m+2),A_ub=np.array(rows),b_ub=rhs,bounds=[(0,None)]*(m+2),method='highs')
  results[mode+'_'+leaf]={'status':int(z.status),'message':z.message,'constraints':len(rows),'x':None if z.x is None else z.x.tolist()}
  print(mode,leaf,z.status,'constraints',len(rows),None if z.x is None else np.round(z.x,6).tolist())
(P/'leaf_lps.json').write_text(json.dumps(results,indent=2)+'\n')
(P/'profile_families.json').write_text(json.dumps(allfamilies,indent=2)+'\n')
