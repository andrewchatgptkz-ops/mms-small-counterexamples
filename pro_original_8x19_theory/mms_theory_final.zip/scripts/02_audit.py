from pathlib import Path
import json, sys
import numpy as np
import networkx as nx
ROOT=Path('/mnt/data/mms_theory')
P=ROOT/'repo/mms-two-type-counterexamples/instances'
sys.path.insert(0,str(ROOT/'input'))
from verify_certificate import INSTANCES,CHAIN

def ss(v):
 a=np.zeros(1<<len(v),dtype=np.int64)
 for j,x in enumerate(v): a[1<<j:1<<(j+1)]=a[:1<<j]+x
 return a

def goods(mask,m): return [i+1 for i in range(m) if mask>>i&1]

def graph(d):
 G=nx.Graph()
 for side,key in [('r','rows_R_sum_T'),('c','cols_C_sum_T')]:
  for i,b in enumerate(d[key],1): G.add_node((side,i),side=side)
 loc={g:i for i,b in enumerate(d['cols_C_sum_T'],1) for g in b}
 for i,b in enumerate(d['rows_R_sum_T'],1):
  for g in b: G.add_edge(('r',i),('c',loc[g]),g=g)
 return G

out={}
for n,m in [(4,11),(5,13),(6,15),(7,17)]:
 d=json.loads((P/f'{n}x{m}.json').read_text()); inst=INSTANCES[f'{n}x{m}']
 R,C,T=d['R'],d['C'],d['T']; a,b=inst['a'],inst['b']; rows=d['rows_R_sum_T']; cols=d['cols_C_sum_T']
 assert all(sum(R[g-1] for g in row)==T for row in rows)
 assert all(sum(C[g-1] for g in col)==T for col in cols)
 cr=[sum(C[g-1] for g in row) for row in rows]; rc=[sum(R[g-1] for g in col) for col in cols]
 hr=[j+1 for j,x in enumerate(cr) if x>=T]; hc=[j+1 for j,x in enumerate(rc) if x>=T]
 print(f'{n}x{m}: T={T}, split={a}+{b}; C(row)={cr}; R(col)={rc}; hard rows={hr}, hard cols={hc}')
 assert len(hr)==b-1 and len(hc)==a-1
 dat=dict(T=T,a=a,b=b,C_rows=cr,R_cols=rc,hard_rows=hr,hard_cols=hc)
 if n>=5:
  w=CHAIN['caseR']['w'][:m]; wr=[sum(w[g-1] for g in row) for row in rows]; wc=[sum(w[g-1] for g in col) for col in cols]
  print('  case R weights: rows=',wr,'columns=',wc,'total=',sum(w))
  sumsR,sumsC,sumsW=ss(R),ss(C),ss(w); masks=np.arange(1<<m)
  poorR=sumsW<22; poorC=(sumsW<23)&((masks&1)==0)
  maxR=int(sumsR[poorR].max()); maxC=int(sumsC[poorC].max())
  witnessR=int(masks[poorR&(sumsR==maxR)][0]); witnessC=int(masks[poorC&(sumsC==maxC)][0])
  print('  max value under weight quota: R=',maxR,goods(witnessR,m),'C avoiding g1=',maxC,goods(witnessC,m))
  dat.update(row_weights=wr,col_weights=wc,poor_max_R=maxR,poor_max_C=maxC,poor_witness_R=goods(witnessR,m),poor_witness_C=goods(witnessC,m))
  activeR=masks[poorR&(sumsR==T-1)]; activeC=masks[poorC&(sumsC==T-1)]
  print('  tight losing inequalities: R=',len(activeR),'C=',len(activeC))
  dat.update(tight_poor_R=[goods(int(s),m) for s in activeR],tight_poor_C=[goods(int(s),m) for s in activeC])
 out[f'{n}x{m}']=dat

# List all possible side-preserving identifications of an edge subdivision of 4x11 with 5x13.
d4=json.loads((P/'4x11.json').read_text());d5=json.loads((P/'5x13.json').read_text());g4=graph(d4);g5=graph(d5)
maps=[]
for u,v,ed in list(g4.edges(data=True)):
 if u[0]=='c':u,v=v,u
 h=g4.copy(); h.remove_edge(u,v);h.add_node(('c',5),side='c');h.add_node(('r',5),side='r')
 h.add_edge(u,('c',5),g=ed['g']);h.add_edge(('c',5),('r',5),g=12);h.add_edge(('r',5),v,g=13)
 GM=nx.algorithms.isomorphism.GraphMatcher(h,g5,node_match=lambda a,b:a['side']==b['side'])
 for mp in GM.isomorphisms_iter():
  gm={e['g']:g5.edges[mp[x],mp[y]]['g'] for x,y,e in h.edges(data=True)}
  maps.append(dict(old_edge=ed['g'],vertex_map={str(k):str(v) for k,v in mp.items()},good_map=gm,new_path=[gm[ed['g']],gm[12],gm[13]],matches=sum(gm[i]==i for i in range(1,12))))
maps.sort(key=lambda d:(-d['matches'],d['old_edge'],list(d['good_map'].values())))
print('4->5 side-preserving subdivision identifications:',len(maps))
print('Chosen (maximises unchanged labels):',json.dumps(maps[0],sort_keys=True))
out['4_to_5_maps']=maps
(ROOT/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
