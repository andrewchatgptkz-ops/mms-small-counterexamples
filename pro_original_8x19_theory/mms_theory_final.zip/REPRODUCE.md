# Reproduction

Initial archive: `/mnt/data/mms_kit_v3(2).zip`.

`python scripts/00_restore.py` restores the two supplied archives.

python scripts/02_audit.py | tee logs/02_audit.txt

python scripts/03_profile_input.py | tee logs/03_profile_input.txt
g++ -O2 -std=c++17 scripts/04_profile_packings.cpp -o scripts/04_profile_packings
scripts/04_profile_packings < 8x19_input.txt | tee logs/04_profile_packings.json

python scripts/05_leaf_lps.py | tee logs/05_leaf_lps.txt

python scripts/06_nearby_direction.py | tee logs/06_nearby_direction.txt

python scripts/07_exact_nearby.py | tee logs/07_exact_nearby.txt

scripts/04_profile_packings < 8x19_depth2_input.txt | tee logs/08_depth2_packings_T104.json
scripts/04_profile_packings < 8x19_depth2_B_input.txt | tee logs/09_depth2_packings_B103.json

python scripts/10_gadgets.py | tee logs/10_gadgets.txt

python scripts/11_invariants.py | tee logs/11_invariants.txt

python verify_new_certificate.py | tee logs/13_standalone_verification.txt
python scripts/12_core_graphs.py | tee logs/12_core_graphs.txt

## Fast independent verification

From this extracted directory, run:

    python verify_new_certificate.py

This uses only the Python standard library and the two profile JSON files. Expected last line:

    NEW CERTIFICATE AND PARAMETRIC THEOREM VALID

The supplied original certificate verifier can be rerun with:

    python input/verify_certificate.py

The commands above that use scripts under /mnt/data/mms_theory assume that extraction path; change their ROOT/P constants to use another path. The standalone new checker is path-independent.

For independent packing verification:

    g++ -O2 -std=c++17 scripts/04_profile_packings.cpp -o scripts/04_profile_packings
    scripts/04_profile_packings < 8x19_depth2_input.txt
    scripts/04_profile_packings < 8x19_depth2_B_input.txt

Expected tuple-pair totals: 0 at 104; 56 at 103. Each check is guarded by 100,000,000 recursive states and 10,000,000 completed tuples per type; all supplied runs completed within both guards.

## Discovery reproducibility

The discovery LP/MILP scripts require NumPy and SciPy; graph checks additionally require NetworkX. Exact versions and input hash are in logs/14_environment.txt. No stochastic search was run and no random seed was used. HiGHS may select different equivalent certificates across versions; exact verification of the retained certificate does not require HiGHS.

The nearby MILP's explicit search bounds were |direction coordinate|<=8, weight/quota<=256 and node_limit=32. It solved at one node. Its optimal deletion count is not asserted to be globally minimal outside that bounded model. All new certificate numbers were rationally reconstructed and then independently checked using integer arithmetic.

## Source restoration warning

scripts/00_restore.py is the record of the initial restoration, not an update script: rerunning it overwrites REPORT.md and REPRODUCE.md with their initial stage-zero versions. The final archive already includes all restored inputs; do not run it for ordinary verification.
